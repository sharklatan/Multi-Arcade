#include "windows.h"

#define IDC_STATIC                      1
#define IDD_CONFIG                      101
#define IDC_25                          1000
#define IDC_0                           1001
#define IDC_50                          1002
#define IDC_75                          1003
#define IDC_100                         1004
#define IDC_PERCENT                     1005
#define IDC_CUSTOM                      1006


