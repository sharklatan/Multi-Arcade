#include "plugins.h"

void Init(HWND Parent, char Is555,char Is32bit,char Rotated)
{

}

unsigned int SetWidth(unsigned short width)
{

    return 2*width;
}

unsigned int SetHeight(unsigned short height)
{

    return 2*height;
}

void Blit(unsigned short width,unsigned short height,unsigned short *src,unsigned int srcpitch,unsigned short *dst,unsigned int dstpitch,unsigned int *palette32)
{
    int j;
    unsigned short *lines=src;
    unsigned short *lined=dst;
    for(j=0;j<height;++j)
    {
        unsigned short *pixels=lines;
        unsigned short *pixeld=lined;
        register int i;

        for(i=0;i<width;++i)
        {
            register unsigned short pixel=*pixels;
            pixeld[0]=pixel;
            pixeld[1]=pixel;
            pixeld+=2;
            ++pixels;
        }
        lines+=srcpitch;
        lined+=2*dstpitch/2;
    }
}

void Configure(HINSTANCE Handler,HWND Parent)
{

}

void Terminate()
{

}

struct _PluginInfo PluginInfo=
{
    PLUGINVER,
    VIDEOPLUGIN,
    "Unfiltered Scanlines",
    "ElSemi",
    "http://nebula.emulatronia.com",
    1,
    0,
	//VideoInterface
    SUPPORTS16BIT,
	Init,
	SetWidth,
	SetHeight,
	Blit,
    NULL,
    Terminate
};


struct _PluginInfo __declspec(dllexport) * __cdecl GetInterface()
{
	return &PluginInfo;
}
