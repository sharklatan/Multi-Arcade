#include "..\plugins.h"

void superscale_line(unsigned short *src0,unsigned short *src1,unsigned short *src2,unsigned short *dst,unsigned int width);
void superscale_line_75(unsigned short *src0,unsigned short *src1,unsigned short *src2,unsigned short *dst,unsigned int width,unsigned __int64 *mask);

unsigned __int64 mask;

void Init(HWND Parent, char Is555,char Is32bit,char Rotated)
{
    if(Is555)
    {
	mask=0x3DEF3DEF3DEF3DEF;
    }
    else
    {
	mask=0x7BEF7BEF7BEF7BEF;
    }
}

unsigned int SetWidth(unsigned short width)
{
    return 2*width;
}

unsigned int SetHeight(unsigned short height)
{

    return 2*height;
}

void Blit(unsigned short width,unsigned short height,unsigned short *src,unsigned int srcpitch,unsigned short *dst,unsigned int dstpitch,unsigned int *palette32)
{
    unsigned short *dst0=dst;
    unsigned short *dst1=dst+dstpitch/2;
    unsigned short *src0=src-srcpitch;  //don't worry, there is extra space :)
    unsigned short *src1=src+0;
    unsigned short *src2=src+srcpitch;
    int i;
    for(i=0;i<height;++i)
    {
        superscale_line(src0,src1,src2,dst0,width);
        superscale_line_75(src2,src1,src0,dst1,width,&mask);
        src0=src1;
        src1=src2;
        src2+=srcpitch;
        dst0+=dstpitch;
        dst1+=dstpitch;
    }
    asm("emms");
}

void Terminate()
{

}

struct _PluginInfo PluginInfo=
{
    PLUGINVER,
    VIDEOPLUGIN,
    "SuperScale 75% Scanlines",
    "ElSemi",
    "http://nebula.emulatronia.com",
    1,
    0,
	//VideoInterface
    SUPPORTS16BIT,
	Init,
	SetWidth,
	SetHeight,
	Blit,
    NULL,
    Terminate
};


struct _PluginInfo __declspec(dllexport) * __cdecl GetInterface()
{
	return &PluginInfo;
}
